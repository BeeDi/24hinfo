<?php
// Setup the webroot
	const BEN = '/media/www-dev/public/challenge';
	const PROD = '';
	const CSV = '/Inscrits.csv';
	const CURRENT = BEN;
	set_include_path(get_include_path() . PATH_SEPARATOR . LOCALHOST);

// Include generic functions
	require 'functions.php';


if(empty($_GET['a'])){
	$controller = Controller_Index::getInstance('Index');
	$controller->welcome();
}
else{
	switch($_GET['a']){
		case 'accueil' : 
			$controller = Controller_Index::getInstance('Index');
			$controller->welcome();
			break;
		case 'inscription':
			$controller = Controller_Index::getInstance('Index');
			$controller->subscribe();
			break;
		case 'inscrits':
			$controller = Controller_Index::getInstance('Index');
			$controller->index();
			break;
		
		default:
			Controller_Error::documentNotFound("Page introuvable : URL incorrecte");
	}
}
?>
