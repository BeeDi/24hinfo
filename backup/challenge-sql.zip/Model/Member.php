<?php
/*

*/
class Model_Member extends Model_Template{

	protected $insertMember;
	protected $updateMember;

	public function __construct(){
		parent::__construct();
		$sql = 'SELECT e.id, e.nom, iut.ville, m.nom, m.prenom, m.id
				FROM equipe AS e
				LEFT JOIN iut ON e.dsIUT = e.id
				LEFT JOIN membre as m ON m.dsEquipe = e.id
				ORDER BY m.nom';
		// $this->selectAll = Controller_Template::$db->prepare($sql);
		
		$sql = 'SELECT e.id, e.nom, iut.ville, m.nom, m.prenom, m.id
				FROM equipe AS e
				LEFT JOIN iut ON e.dsIUT = e.id
				LEFT JOIN membre as m ON m.dsEquipe = e.id
				WHERE m.id = ?';
		$this->selectById = Controller_Template::$db->prepare($sql);

		$sql ='INSERT INTO membre (nom, prenom, role, dsEquipe) VALUES (?, ?, \'etudiant\', ?)';
		$this->insertMember = Controller_Template::$db->prepare($sql);

		// $sql ='';
		// $this->updateMember = Controller_Template::$db->prepare($sql);
	}

	public function insert($lName, $fName, $team) {
		$count = $this->insertMember->execute(array($lName, $fName, $team));
		return $count;
	}

	public function update() {
		
	}

}

