<?php
/*

*/
class Model_IUT extends Model_Template{

	public function __construct(){
		parent::__construct();
		// // CSV
		// $file = fopen('./IUT.csv','r+');
		$sql = 'SELECT iut.id, iut.ville
				FROM iut 
				ORDER BY iut.ville';
		$this->selectAll = Controller_Template::$db->prepare($sql);
		
		$sql = 'SELECT iut.id, iut.ville
				FROM iut 
				WHERE iut.id = ?';
		$this->selectById = Controller_Template::$db->prepare($sql);

	}

}

