<?php
/*

*/
class Model_Team extends Model_Template{

	protected $insertTeam;
	protected $updateTeam;
	protected $countTeam;

	public function __construct(){
		parent::__construct();
		$sql = 'SELECT e.id as Eid, e.nom as Enom, e.mail, iut.ville, m.id, m.nom, m.prenom 
				FROM equipe AS e
				LEFT JOIN iut ON e.deIUT = iut.id
				LEFT JOIN membre as m ON m.dsEquipe = e.id
				ORDER BY e.id, m.nom';
		$this->selectAll = Controller_Template::$db->prepare($sql);
		
		$sql = 'SELECT e.id as Eid, e.nom as Enom, e.mail, iut.ville, m.id, m.nom, m.prenom 
				FROM equipe AS e
				LEFT JOIN iut ON e.deIUT = iut.id
				LEFT JOIN membre as m ON m.dsEquipe = e.id
		 		WHERE e.id = ?
		 		ORDER BY m.nom';
		$this->selectById = Controller_Template::$db->prepare($sql);

		$sql = 'INSERT INTO equipe (nom, deIUT, mail) VALUES (?,?,?)';
		$this->insertTeam = Controller_Template::$db->prepare($sql);

		$sql = 'SELECT COUNT(*) as nb FROM equipe';
		$this->countTeam = Controller_Template::$db->prepare($sql);

		// $sql ='';
		// $this->updateTeam = Controller_Template::$db->prepare($sql);
	}

	public function insert($name, $iut, $mail) {
		$count = $this->insertTeam->execute(array($name, $iut, $mail));
		return $count;
	}

	public function update() {
		
	}

	public function countTeam() {
		$nbTeam = $this->countTeam->execute();
		$nbTeam = $this->countTeam->fetchAll();
		// echo $nbTeam;
		return $nbTeam[0];
	}

	// // public function getAll() {
	// // 	$this->selectAll->execute();
	// // 	return $this->selectAll->fetchAll(PDO::FETCH_COLUMN|PDO::FETCH_GROUP);
	// // }

	// // public function getById($id){
	// // 	$this->selectById->execute(array($id));
	// // 	$row = $this->selectById->fetchAll(PDO::FETCH_COLUMN|PDO::FETCH_GROUP);
	// // 	if(empty($row[0])){
	// // 		return array();
	// // 	}
	// // 	else{
	// // 		return $row[0];
	// // 	}
	// }
}

