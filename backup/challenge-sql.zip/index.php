<?php
// Setup the webroot
	LOCALHOST = '/media/www-dev/public/challenge';
	DEBUG = '/home/profs/diemert/public_html/trophee';
	PROD = '';
	set_include_path(get_include_path() . PATH_SEPARATOR . DEBUG);

// Include generic functions
	require 'functions.php';

// Database Connection
	// Controller_Template::$db = new MyPDO('mysql:host=database-etudiants;dbname=challenge', 'donald', 'duck');


if(empty($_GET['a'])){
	$controller = Controller_Index::getInstance('Index');
	$controller->welcome();
}
else{
	switch($_GET['a']){
		case 'accueil' : 
			$controller = Controller_Index::getInstance('Index');
			$controller->welcome();
			break;
		case 'inscription':
			$controller = Controller_Index::getInstance('Index');
			$controller->subscribe();
			break;
		case 'inscrits':
			$controller = Controller_Index::getInstance('Index');
			$controller->index();
			break;

		case 'membre':
			if (isset($_GET['id'])) { 
				$controller = Controller_Index::getInstance('Index');
				$controller->display((int)$_GET['id']);
			}
			break;
		
		default:
			Controller_Error::documentNotFound("Page introuvable : URL incorrecte");
	}
}
?>
