<?php
class Controller_Index extends Controller_Template{

	protected function __construct(){
		parent::__construct();
		$this->TeamModel = new Model_Team();
		$this->IUTModel = new Model_IUT();
		$this->MemberModel = new Model_Member();
	}

	public function welcome(){
		$title = utf8_decode("Trophée informatique des IUT"); 

		header('Content-Type: text/html; charset=utf-8');
		require 'View/header.tpl';
		require 'View/index/index.tpl';
		require 'View/footer.tpl';
	}

	public function subscribe(){

		// Check if the form has been filled
		if (!empty($_POST['subscribe'])) {
			// When the form is filled: Validation + Error Checking

			// Initialize error message
			$errorE = array();
			$errorM = array();

			// Team Name ? 
			(!empty($_POST['nomE'])) ? $_POST['nomE'] = trim($_POST['nomE']) : $errorE[] = 'Veuillez entrer un nom d\'équipe !';
			// IUT ? 
			(!empty($_POST['iut'])) ? $_POST['iut'] = trim($_POST['iut']) : $errorE[] = 'Veuillez sélectionner votre IUT !';
			// Mail ? 
			(!empty($_POST['mail'])) ? $_POST['mail'] = trim($_POST['mail']) : $errorE[] = 'Veuillez sélectionner un mél de contact !';

			// Last + First Name of Members
			(!empty($_POST['Lname1'])) ? $_POST['Lname1'] = trim($_POST['Lname1']) : $errorM[] = 'Veuillez entrer un nom !';
			(!empty($_POST['Fname1'])) ? $_POST['Fname1'] = trim($_POST['Fname1']) : $errorM[] = 'Veuillez entrer un prénom !';

			// Check if there are errors in the form
			if (empty($errorM) && empty($errorE)) {
				// No error: Insert data and display the team list
				$this->TeamModel->insert($_POST['nomE'], $_POST['iut'], $_POST['mail']);
				$teamID = Controller_Template::$db->lastInsertId();

				for ($i=1;$i<=6;$i++) {
					if (!empty($_POST['Lname'.$i])) {
						$this->MemberModel->insert($_POST['Lname'.$i], $_POST['Fname'.$i], $teamID);
					}
				}
				$this->index();
			}
			else {
				// Error(s) are present, we display the form again !
				$iuts = $this->IUTModel->getAll();
				$title = utf8_decode("Vérifiez votre inscription au Trophée"); 
				header('Content-Type: text/html; charset=utf-8');
				require 'View/header.tpl';
				require 'View/index/subscribe.tpl';
				require 'View/footer.tpl';
			}
		}
		else {
			// If the form has not been filled, first time opening !  
			$iuts = $this->IUTModel->getAll();
			$title = utf8_decode("Inscription au Trophée"); 
			header('Content-Type: text/html; charset=utf-8');
			require 'View/header.tpl';
			require 'View/index/subscribe.tpl';
			require 'View/footer.tpl';
		}
		
			
		

		
	}

	public function index(){
		$teams = $this->TeamModel->getAll();

		$nb = $this->TeamModel->countTeam();

		$title = utf8_decode("Inscrits au Challenge"); 
		header('Content-Type: text/html; charset=utf-8');
		require 'View/header.tpl';
		require 'View/index/listing.tpl';
		require 'View/footer.tpl';
	}
}

