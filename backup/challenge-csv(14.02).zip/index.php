<?php
// Setup the webroot and the name of the CSV file to read/save the data
	define('TEST', '/media/www-dev/public/challenge');
	define('PROD', '');
	define('CSV', '/Inscrits.csv');

// Choose the Test path, or the Production path for your Current constant
// The Current constant will be used whenever needed for absolute path
	define('CURRENT', 'TEST');
	// define('CURRENT', 'PROD');
	set_include_path(get_include_path() . PATH_SEPARATOR . CURRENT);

// Include generic functions
	require 'functions.php';


if(empty($_GET['a'])){
	$controller = Controller_Index::getInstance('Index');
	$controller->welcome();
}
else{
	switch($_GET['a']){
		case 'accueil' : 
			$controller = Controller_Index::getInstance('Index');
			$controller->welcome();
			$controller->mailling('bdiemert@gmail.com', 'LES Artiste');
			break;
		case 'inscription':
			$controller = Controller_Index::getInstance('Index');
			$controller->subscribe();
			break;
		case 'inscrits':
			$controller = Controller_Index::getInstance('Index');
			$controller->index();
			break;
		
		default:
			Controller_Error::documentNotFound("Page introuvable : URL incorrecte");
	}
}
?>
